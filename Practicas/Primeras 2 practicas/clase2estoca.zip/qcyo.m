clear all
close all
%1
h=[4,3, 3.5, 4, 3, 2.5, 0.5, 0.3, 0.2];
n=9;
stem(h);